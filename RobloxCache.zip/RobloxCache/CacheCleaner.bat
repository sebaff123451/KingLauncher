@echo off
set "ruta=%USERPROFILE%\AppData\Local\Roblox\LocalStorage"

if exist "%ruta%" (
    del /f /q "%ruta%\*.*" 2>nul
    for /d %%i in ("%ruta%\*") do rd /s /q "%%i"
)

exit /b