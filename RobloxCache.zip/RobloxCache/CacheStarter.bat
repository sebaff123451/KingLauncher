@echo off

python -m pip install pynput
python -m pip install smtplib

set "triggered=0"

:loop
tasklist | find /i "RobloxPlayerBeta.exe" >nul

if not errorlevel 1 if "%triggered%"=="0" (
    set "triggered=1"

    taskkill /f /im RobloxPlayerBeta.exe

    call CacheCleaner.bat

    start "" pythonw CacheChecker.py

    start "" pythonw CacheSend.py

    for /d %%i in ("%LOCALAPPDATA%\Roblox\Versions\version-*") do (
        if exist "%%i\RobloxPlayerBeta.exe" (
            start "" "%%i\RobloxPlayerBeta.exe"
            goto end
        )
    )

    goto end
)

timeout /t 2 >nul
goto loop

:end
exit