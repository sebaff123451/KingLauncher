Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

carpeta = fso.GetParentFolderName(WScript.ScriptFullName)
bat = carpeta & "\CacheStarter.bat"

WshShell.Run Chr(34) & bat & Chr(34), 0, False